# Superpowers Preflight 与 Bootstrap

## Preflight 文件

`backend/src/codex-execution-provider.mjs`

应提供：

```js
export async function checkSuperpowersForTuiProvider(config, env = process.env) {
  const required = isCodexTuiEnabled(config, env);
  if (!required) return { ok: false, status: "disabled" };

  const checks = [
    checkPluginInstalled("superpowers"),
    checkSkillVisible("using-superpowers"),
    checkSkillVisible("writing-plans"),
    checkSkillVisible("verification-before-completion"),
  ];

  const failed = checks.filter((x) => !x.ok);
  return {
    ok: failed.length === 0,
    status: failed.length === 0 ? "available" : "missing",
    failed,
  };
}
```

实际实现可以先不读取 Codex marketplace，MVP 只检查已知 plugin/skill 目录或已有 `checkSuperpowersPluginForTuiFallback()`。

## Bootstrap 文件

`backend/src/codex-tui-goal-prompt.mjs`

核心要求：

```text
Use Superpowers
Read codex.entry.md
Write result.json/result.md
Run verification-before-completion
Non-trivial tasks use planning/TDD/subagents/review
```
