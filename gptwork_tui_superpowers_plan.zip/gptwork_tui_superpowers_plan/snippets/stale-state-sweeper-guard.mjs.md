# backend/src/stale-state-sweeper.mjs

```js
function isCodexTuiTask(task, result = {}) {
  const metadata = task?.metadata || {};
  return metadata.codex_execution_provider === "codex_tui_goal"
    || metadata.execution_backend === "codex_tui_superpowers"
    || result.provider === "codex_tui_goal"
    || result.execution_backend === "codex_tui_superpowers"
    || result.kind === "codex_tui_session_started"
    || typeof result.session_id === "string";
}
```

```js
if (staleFor > staleThresholdMs * 3 && blockerFindings.length === 0) {
  if (isCodexTuiTask(task, result) && !hasEvidence) return actions;

  if (profile !== "code_change") {
    actions.push({
      taskId: task.id,
      currentStatus: TASK_STATUSES.WAITING_FOR_REVIEW,
      recommendedStatus: TASK_STATUSES.COMPLETED,
      reason: `Auto-sweep: stale waiting_for_review (${Math.round(staleFor / 1000)}s) with no blockers — force completing.`,
      actions: [{ type: "update_task_status", payload: { status: TASK_STATUSES.COMPLETED } }],
    });
  }
}
```
