# backend/src/codex-tui-pty-adapter.mjs

```js
async function loadNodePty() {
  try {
    return await import("node-pty");
  } catch (err) {
    throw createCodexTuiUnavailableError(err);
  }
}

function createScriptFallbackSession({ cwd, env, onData, spawnImpl, args = [] } = {}) {
  const proc = spawnImpl("script", ["-q", "-f", "-c", codexCommand(args), "/dev/null"], {
    cwd,
    env,
    stdio: ["pipe", "pipe", "pipe"],
  });

  proc.stdout?.on?.("data", (chunk) => onData?.(String(chunk)));
  proc.stderr?.on?.("data", (chunk) => onData?.(String(chunk)));

  return {
    pid: proc.pid ?? null,
    adapter: "script",
    write(text) {
      proc.stdin?.write?.(String(text ?? ""));
    },
    stop(signal = "SIGTERM") {
      try { proc.stdin?.end?.(); } catch {}
      try { proc.kill?.(signal); } catch {}
    },
  };
}
```
