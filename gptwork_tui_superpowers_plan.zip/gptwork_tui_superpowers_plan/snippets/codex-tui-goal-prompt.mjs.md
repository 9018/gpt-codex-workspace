# backend/src/codex-tui-goal-prompt.mjs

```js
export function buildCodexTuiGoalObjective({ goalId, taskTitle }) {
  return [
    `goal_id=${goalId}`,
    `task=${taskTitle || "GPTWork task"}`,
    "",
    "Use Superpowers for this task.",
    `Read .gptwork/goals/${goalId}/codex.entry.md before planning or editing.`,
    "",
    "Execution contract:",
    `- Write .gptwork/goals/${goalId}/result.json`,
    `- Write .gptwork/goals/${goalId}/result.md`,
    "- Include changed_files, tests, verification, blockers, and commit if any.",
    "- Do not declare completion until verification-before-completion has been performed.",
    "- For non-trivial implementation, use Superpowers planning/TDD/subagent/review workflows.",
    "",
    "When done, print a concise STATUS/SUMMARY/CHANGED_FILES/TESTS/COMMIT report."
  ].join("\n");
}
```
