# backend/src/task-general-processor.mjs

```js
if (taskUsesCodexTuiGoal(task)) {
  const started = await startCodexTuiGoalSessionFn({
    task,
    goal,
    cwd: executionCwd,
    repoLockId: null,
  });

  const sessionStartedResult = {
    kind: "codex_tui_session_started",
    provider: "codex_tui_goal",
    execution_backend: "codex_tui_superpowers",
    tui_phase: "session_started",
    status: "waiting_for_review",
    session_id: started.id,
    task_id: task.id,
    goal_id: goal.id,
    cwd: started.cwd || executionCwd,
    changed_files: [],
    tests: null,
    commit: "none",
    verification: {
      passed: false,
      findings: [{
        severity: "major",
        code: "tui_evidence_missing",
        message: "Codex TUI session started, but durable result evidence has not been collected yet."
      }]
    }
  };

  await updateTaskResult(store, task.id, sessionStartedResult);

  const collected = await runCodexTuiEvidenceCycle({
    task,
    goal,
    sessionId: started.id,
    workspaceRoot: config.defaultWorkspaceRoot,
    maxWaitMs: config.codexTuiEvidenceWaitMs ?? 120_000,
  });

  if (!collected.evidence_ready) {
    await updateTaskResult(store, task.id, {
      ...sessionStartedResult,
      tui_phase: "blocked_missing_evidence",
      verification: {
        passed: false,
        findings: [collected.finding],
      },
      collect_result: collected,
    });
    await updateTaskStatus(store, task.id, TASK_STATUSES.WAITING_FOR_REVIEW);
    return {
      kind: "codex_tui_awaiting_evidence",
      status: "waiting_for_review",
      session_id: started.id,
      reason: collected.reason,
    };
  }

  // Continue through normal acceptance/finalizer path with collected evidence.
}
```
