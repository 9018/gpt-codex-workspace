# Provider Contract

## 输入 metadata

```json
{
  "codex_execution_provider": "codex_tui_goal",
  "execution_backend": "codex_tui_superpowers",
  "requires_superpowers": true,
  "must_use_tui": true
}
```

## 兼容策略

`codex_tui_goal` 保留，不改名为 breaking change。

但内部 runtime 应理解为：

```text
codex_tui_goal + execution_backend=codex_tui_superpowers
```

## 缺 Superpowers 时

返回：

```json
{
  "kind": "codex_tui_superpowers_missing",
  "status": "provider_blocked",
  "provider": "codex_tui_goal",
  "execution_backend": "codex_tui_superpowers",
  "reason": "Superpowers plugin or required skills are unavailable"
}
```

不要 fallback 到 `codex_exec`，除非 task metadata 明确允许。
