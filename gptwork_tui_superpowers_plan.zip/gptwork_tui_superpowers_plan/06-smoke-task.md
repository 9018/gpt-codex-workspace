# P0-TUI-SMOKE Durable Evidence Loop

## Task metadata

```json
{
  "codex_execution_provider": "codex_tui_goal",
  "execution_backend": "codex_tui_superpowers",
  "requires_superpowers": true,
  "must_use_tui": true,
  "smoke": true
}
```

## Task body

Validate that GPTWork TUI provider can produce durable evidence.

Requirements:
1. Use Codex TUI + Superpowers.
2. Do not modify product source.
3. Write `.gptwork/goals/<goal_id>/result.json`.
4. Write `.gptwork/goals/<goal_id>/result.md`.
5. result.json must include:
   - `changed_files: []`
   - `tests: "smoke evidence only"`
   - `verification.passed: true`
   - `commit: "none"`
6. `codex_tui_collect` must detect evidence.
7. Task must not complete from `session_started` alone.
