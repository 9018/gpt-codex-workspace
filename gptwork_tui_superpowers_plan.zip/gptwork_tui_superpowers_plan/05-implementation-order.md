# Implementation Order

1. Keep `b871e72`, `8aa66cd`, `6c4cfa2`.
2. Do not create more big TUI productization tasks until smoke loop passes.
3. Add `backend/src/codex-tui-evidence-cycle.mjs`.
4. Integrate it into `backend/src/task-general-processor.mjs`.
5. Strengthen `backend/src/codex-tui-goal-prompt.mjs`.
6. Add tests.
7. Create one smoke task only.
8. After smoke passes, reopen P0-TUI-01~06 or recreate smaller tasks.
