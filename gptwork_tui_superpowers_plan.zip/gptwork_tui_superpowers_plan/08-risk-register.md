# Risk Register

## Risk: TUI process starts but does not execute

Mitigation:
- bounded result wait
- missing evidence finding
- no auto-complete

## Risk: sweeper false completion

Mitigation:
- `isCodexTuiTask()` guard
- tests for session-only task

## Risk: dirty worktree from parallel tasks

Mitigation:
- do not clean unrelated files
- TUI smoke task writes only `.gptwork/goals/<goal_id>/`

## Risk: node-pty missing

Mitigation:
- `script(1)` fallback
- adapter tests

## Risk: restart breaks MCP

Mitigation:
- no service restart unless explicitly needed
- dry-run before restart
- never restart while worker tick is running unless operator confirms
