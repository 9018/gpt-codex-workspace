# TUI Runner 状态机

## MVP 不新增 task.status

使用 `task.result.tui_phase`：

```text
session_started
awaiting_evidence
evidence_collected
acceptance_running
repair_requested
blocked_missing_evidence
completed
```

## 状态转换

```text
created
  ↓
assigned
  ↓
worker detects codex_tui_goal
  ↓
session_started
  ↓
awaiting_evidence
  ↓
[missing result.json] → waiting_for_review + tui_phase=blocked_missing_evidence
  ↓
[result.json exists] → evidence_collected
  ↓
acceptance_running
  ↓
pass → completed / integration
fail → repair_requested → same-session repair
```

## 关键规则

```text
session_started 只能表示 TUI 打开了。
session_started 不能表示任务做完了。
session_started 不能触发 completed。
```
