# GPTWork Codex TUI + Superpowers 自动执行闭环方案

版本：2026-07-08  
目标：把 `codex_tui_goal` 从“只启动交互式 TUI session 的人工 fallback”升级为 **Superpowers-backed Codex native session runner**。  
原则：**session started 不是完成证据**。任何 TUI 任务没有 `result.json/result.md/tests/commit/verification` 等 durable evidence 时，不得进入 `completed`。

---

## 0. 当前诊断

当前实际行为：

```text
task.metadata.codex_execution_provider = codex_tui_goal
→ worker 启动 Codex TUI session
→ 写入 /goal 和 follow-up 指令
→ 任务进入 waiting_for_review
→ 不自动等待 result.json
→ 不自动 codex_tui_collect
→ 不自动 acceptance
→ sweeper 可能把 stale waiting_for_review 错误 completed
```

因此，之前批量下发的 TUI 改造任务不能算有效完成。它们最多证明：

```text
TUI session starter 可被触发
PTY/node-pty/fallback 问题暴露
session record 可落盘
```

但没有证明：

```text
Superpowers workflow 被执行
代码被修改
测试被运行
result evidence 被收集
acceptance/integration 闭环通过
```

### 必须修正的语义

| 事件 | 是否等价于完成 |
|---|---|
| `codex_tui_session_started` | 否 |
| `.gptwork/codex-tui-sessions/*.json` 存在 | 否 |
| `.log` 有 TUI 输出 | 否 |
| `result.json` 存在且 schema 合法 | 部分证据 |
| tests / verification passed | 强证据 |
| commit / changed_files 与任务一致 | 强证据 |
| acceptance gate passed | 才可完成或进入 integration |

---

## 1. 总体架构

```text
GPTWork Task
  ↓
TUI Provider Router
  ↓
Superpowers Preflight
  ↓
Codex TUI Session Manager
  ↓
Bootstrap:
  - Use Superpowers
  - Read .gptwork/goals/<goal_id>/codex.entry.md
  - Write result.json/result.md
  - Run verification before completion
  ↓
TUI Evidence Wait / Collect Loop
  ↓
collectCodexTuiCompletion()
  ↓
Acceptance Gate
  ↓
pass → integration / completed
fail → same-session repair instruction
missing evidence → waiting_for_review / blocked_review
```

---

## 2. 一致性约束

### 2.1 Provider 语义

保留旧值，避免 breaking change：

```text
codex_exec
codex_tui_goal
```

推荐新增内部语义字段：

```json
{
  "codex_execution_provider": "codex_tui_goal",
  "execution_backend": "codex_tui_superpowers",
  "requires_superpowers": true
}
```

不要立刻强制改掉所有调用方。`codex_tui_goal` 仍然是兼容入口，但 runtime 语义升级为：

```text
codex_tui_goal = GPTWork-managed Codex TUI session runner
```

而不是：

```text
codex_tui_goal = completed task runner
```

### 2.2 状态语义

MVP 阶段不要强行引入全新 task.status，避免污染现有 taxonomy。

使用现有状态：

```text
waiting_for_review
completed
failed
blocked
```

用 `task.result.tui_phase` 表示细粒度状态：

```text
session_started
awaiting_evidence
evidence_collected
acceptance_running
repair_requested
completed
blocked_missing_evidence
```

后续产品化再引入正式 task statuses：

```text
tui_starting
tui_running
tui_collecting_evidence
acceptance_running
repairing_with_same_session
```

### 2.3 完成条件

TUI task 进入 `completed` 前必须至少满足其中一组：

```text
A. result.verification.passed === true
B. result.acceptance_gate.passed === true
C. result.contract_verification.blocking_passed === true
D. result.tests 有非空通过证据
E. result.commit 是有效 commit 且 reachable
```

禁止：

```text
session_id 存在 → completed
log 存在 → completed
stale waiting_for_review → completed
```

---

## 3. 实施顺序

### P0-Bootstrap：只打通一个最小闭环

先不要再批量下发 6 个大任务。

先实现并验证：

```text
创建一个小 TUI smoke task
→ 启动 TUI
→ 让 TUI 写 .gptwork/goals/<goal_id>/result.json/result.md
→ collect 能读到
→ acceptance 能识别 missing/pass/fail
→ task 不会空跑 completed
```

### P1：Superpowers 硬依赖

```text
TUI provider 运行前检查 Superpowers plugin/skills
缺失则 provider_blocked
不启动空 session
```

### P2：自动 collect

```text
session_started
→ bounded wait/poll result.json
→ collect durable evidence
→ missing evidence: waiting_for_review + finding
→ evidence present: acceptance
```

### P3：same-session repair

```text
acceptance failed
→ codex_tui_send repair prompt
→ wait/poll
→ collect again
```

### P4：native session / resume / app-server

```text
记录 Codex native session id
支持 resume/reconnect
支持 app-server remote
```

---

## 4. 文件级变更总览

| 文件 | 作用 | 必须改动 |
|---|---|---|
| `backend/src/codex-execution-provider.mjs` | provider 选择与 TUI/Superpowers preflight | 保留 `codex_tui_goal`，增加 backend metadata 判断 |
| `backend/src/task-general-processor.mjs` | worker 执行主路径 | TUI 分支不能 start 后直接结束；要进入 evidence collect loop |
| `backend/src/codex-tui-session-manager.mjs` | TUI session 生命周期 | start/read/status/recover/resume，记录 active/detached |
| `backend/src/codex-tui-session-store.mjs` | session durable record/log | 保存 `tui_phase/native/restart_count/evidence_status` |
| `backend/src/codex-tui-goal-prompt.mjs` | bootstrap prompt | 注入 Superpowers + GPTWork result contract |
| `backend/src/codex-tui-completion-collector.mjs` | durable evidence 收集 | 解析 result.json/result.md/git/tests |
| `backend/src/tool-groups/codex-tui-tools-group.mjs` | MCP 工具 | status/read/send/stop/collect/resume，避免只显示 running |
| `backend/src/stale-state-sweeper.mjs` | stale task convergence | 禁止 session-only TUI task 自动 completed |
| `backend/test/codex-tui-*.test.mjs` | TUI 回归测试 | 覆盖 start-only、collect、missing evidence、resume |
| `backend/test/stale-state-sweeper.test.mjs` | sweeper 保护 | 覆盖 TUI session-only 不完成 |

---

## 5. 关键代码片段

### 5.1 `backend/src/stale-state-sweeper.mjs`

目的：防止 TUI 空 session 被 stale sweeper 假完成。

```js
function isCodexTuiTask(task, result = {}) {
  const metadata = task?.metadata || {};
  return metadata.codex_execution_provider === "codex_tui_goal"
    || metadata.execution_backend === "codex_tui_superpowers"
    || result.provider === "codex_tui_goal"
    || result.execution_backend === "codex_tui_superpowers"
    || result.kind === "codex_tui_session_started"
    || typeof result.session_id === "string";
}
```

在 `sweepWaitingForReview()` 的 stale 分支中加入：

```js
if (staleFor > staleThresholdMs * 3 && blockerFindings.length === 0) {
  // TUI sessions are long-lived execution records. A started session without
  // durable result/test/commit evidence must stay reviewable instead of being
  // force-completed by age alone.
  if (isCodexTuiTask(task, result) && !hasEvidence) return actions;

  if (profile !== "code_change") {
    actions.push({
      taskId: task.id,
      currentStatus: TASK_STATUSES.WAITING_FOR_REVIEW,
      recommendedStatus: TASK_STATUSES.COMPLETED,
      reason: `Auto-sweep: stale waiting_for_review (${Math.round(staleFor / 1000)}s) with no blockers — force completing.`,
      actions: [{ type: "update_task_status", payload: { status: TASK_STATUSES.COMPLETED } }],
    });
  }
}
```

### 5.2 `backend/src/codex-tui-goal-prompt.mjs`

目的：不要只发 `/goal`；必须明确 Superpowers 与 GPTWork durable contract。

```js
export function buildCodexTuiGoalObjective({ goalId, taskTitle }) {
  return [
    `goal_id=${goalId}`,
    `task=${taskTitle || "GPTWork task"}`,
    "",
    "Use Superpowers for this task.",
    `Read .gptwork/goals/${goalId}/codex.entry.md before planning or editing.`,
    "",
    "Execution contract:",
    `- Write .gptwork/goals/${goalId}/result.json`,
    `- Write .gptwork/goals/${goalId}/result.md`,
    "- Include changed_files, tests, verification, blockers, and commit if any.",
    "- Do not declare completion until verification-before-completion has been performed.",
    "- For non-trivial implementation, use Superpowers planning/TDD/subagent/review workflows.",
    "",
    "When done, print a concise STATUS/SUMMARY/CHANGED_FILES/TESTS/COMMIT report."
  ].join("\n");
}
```

```js
export function buildCodexTuiFollowupInstruction({ goalId }) {
  return [
    `Continue GPTWork goal_id=${goalId}.`,
    "Use Superpowers.",
    `The entrypoint remains .gptwork/goals/${goalId}/codex.entry.md.`,
    `The durable result contract remains .gptwork/goals/${goalId}/result.json and result.md.`,
    "If context was compacted, re-read the entrypoint and continue from the current repository state.",
  ].join("\n");
}
```

### 5.3 `backend/src/task-general-processor.mjs`

目的：TUI 分支启动后进入 collect loop，而不是把 `session_started` 当 result。

```js
if (taskUsesCodexTuiGoal(task)) {
  const started = await startCodexTuiGoalSessionFn({
    task,
    goal,
    cwd: executionCwd,
    repoLockId: null,
  });

  await updateTaskResult(store, task.id, {
    kind: "codex_tui_session_started",
    provider: "codex_tui_goal",
    execution_backend: "codex_tui_superpowers",
    tui_phase: "session_started",
    session_id: started.id,
    task_id: task.id,
    goal_id: goal.id,
    cwd: started.cwd || executionCwd,
    changed_files: [],
    tests: null,
    commit: "none",
    verification: {
      passed: false,
      findings: [{
        severity: "major",
        code: "tui_evidence_missing",
        message: "Codex TUI session started, but durable result evidence has not been collected yet."
      }]
    }
  });

  const collected = await runCodexTuiEvidenceCycle({
    task,
    goal,
    sessionId: started.id,
    workspaceRoot: config.defaultWorkspaceRoot,
    maxWaitMs: config.codexTuiEvidenceWaitMs ?? 120_000,
  });

  if (!collected?.evidence_ready) {
    await updateTaskStatus(store, task.id, TASK_STATUSES.WAITING_FOR_REVIEW);
    return {
      kind: "codex_tui_awaiting_evidence",
      status: "waiting_for_review",
      session_id: started.id,
      reason: collected?.reason || "result evidence missing",
    };
  }

  // Only after this point may the normal acceptance/finalizer path run.
}
```

### 5.4 新增 `backend/src/codex-tui-evidence-cycle.mjs`

目的：将“等待 result.json → collect → 分类”抽出来，便于测试。

```js
import { existsSync } from "node:fs";
import { join } from "node:path";
import { collectCodexTuiCompletion } from "./codex-tui-completion-collector.mjs";

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function runCodexTuiEvidenceCycle({
  task,
  goal,
  sessionId,
  workspaceRoot,
  collectFn = collectCodexTuiCompletion,
  now = Date.now,
  sleepFn = sleep,
  maxWaitMs = 120_000,
  pollMs = 5_000,
} = {}) {
  if (!goal?.id) throw new Error("goal.id is required");
  if (!sessionId) throw new Error("sessionId is required");

  const resultJsonPath = join(workspaceRoot, ".gptwork", "goals", goal.id, "result.json");
  const deadline = now() + maxWaitMs;

  while (now() < deadline) {
    if (existsSync(resultJsonPath)) break;
    await sleepFn(pollMs);
  }

  const collected = await collectFn({ sessionId, workspaceRoot });

  if (!collected?.result_json && !collected?.result?.result_json_valid) {
    return {
      evidence_ready: false,
      reason: "tui_result_json_missing",
      session_id: sessionId,
      goal_id: goal.id,
      task_id: task?.id || null,
      finding: {
        severity: "major",
        code: "tui_result_json_missing",
        message: `Missing durable result file: ${resultJsonPath}`,
      },
      collected,
    };
  }

  return {
    evidence_ready: true,
    reason: "tui_result_json_collected",
    session_id: sessionId,
    goal_id: goal.id,
    task_id: task?.id || null,
    collected,
  };
}
```

### 5.5 `backend/src/codex-tui-completion-collector.mjs`

目的：collector 结果必须明确“缺 evidence”与“有 evidence”。

```js
export function normalizeCodexTuiEvidence({ sessionId, goalId, resultJson, resultMd, gitEvidence } = {}) {
  const findings = [];

  if (!resultJson) {
    findings.push({
      severity: "major",
      code: "tui_result_json_missing",
      message: "Codex TUI did not write result.json.",
    });
  }

  if (!resultMd) {
    findings.push({
      severity: "minor",
      code: "tui_result_md_missing",
      message: "Codex TUI did not write result.md.",
    });
  }

  const tests = resultJson?.tests || resultJson?.verification?.commands || null;
  const commit = resultJson?.commit || gitEvidence?.commit || "none";
  const changedFiles = Array.isArray(resultJson?.changed_files)
    ? resultJson.changed_files
    : (gitEvidence?.changed_files || []);

  return {
    kind: "codex_tui_evidence",
    provider: "codex_tui_goal",
    execution_backend: "codex_tui_superpowers",
    session_id: sessionId,
    goal_id: goalId,
    evidence_ready: findings.every((f) => f.severity !== "major"),
    changed_files: changedFiles,
    tests,
    commit,
    verification: {
      passed: findings.every((f) => f.severity !== "major") && Boolean(tests),
      findings,
    },
  };
}
```

### 5.6 `backend/src/codex-tui-session-manager.mjs`

目的：status/read 能识别 active vs detached，不把死进程显示为 running。

```js
function isProcessAlive(pid) {
  const n = Number(pid);
  if (!Number.isInteger(n) || n <= 0) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch {
    return false;
  }
}

async function normalizeRecoveredSessionRecord(store, sessionId, record = null) {
  const current = record || await store.readSession(sessionId, { maxChars: 0 });
  if (activeSessions.has(sessionId)) return current;

  if (current.status === "running" && current.pty_pid && !isProcessAlive(current.pty_pid)) {
    return store.updateSession(sessionId, {
      status: "detached",
      detach_reason: "pty_process_not_alive",
      detached_at: new Date().toISOString(),
    });
  }

  return current;
}
```

### 5.7 `backend/src/codex-tui-pty-adapter.mjs`

目的：`node-pty` 不可用时不要直接失败；用 `script(1)` 做 fallback。

```js
async function loadNodePty() {
  try {
    return await import("node-pty");
  } catch (err) {
    throw createCodexTuiUnavailableError(err);
  }
}

function createScriptFallbackSession({ cwd, env, onData, spawnImpl, args = [] } = {}) {
  const proc = spawnImpl("script", ["-q", "-f", "-c", codexCommand(args), "/dev/null"], {
    cwd,
    env,
    stdio: ["pipe", "pipe", "pipe"],
  });

  proc.stdout?.on?.("data", (chunk) => onData?.(String(chunk)));
  proc.stderr?.on?.("data", (chunk) => onData?.(String(chunk)));

  return {
    pid: proc.pid ?? null,
    adapter: "script",
    write(text) {
      proc.stdin?.write?.(String(text ?? ""));
    },
    stop(signal = "SIGTERM") {
      try { proc.stdin?.end?.(); } catch {}
      try { proc.kill?.(signal); } catch {}
    },
  };
}
```

---

## 6. 测试计划

### 6.1 新增测试文件

`backend/test/codex-tui-evidence-cycle.test.mjs`

```js
import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { runCodexTuiEvidenceCycle } from "../src/codex-tui-evidence-cycle.mjs";

test("TUI evidence cycle returns missing when result.json is absent", async () => {
  const workspaceRoot = await mkdtemp(join(tmpdir(), "tui-evidence-"));
  const goal = { id: "goal_missing" };
  const out = await runCodexTuiEvidenceCycle({
    task: { id: "task_missing" },
    goal,
    sessionId: "session_missing",
    workspaceRoot,
    maxWaitMs: 1,
    pollMs: 1,
    sleepFn: async () => {},
    collectFn: async () => ({ result_json: null }),
  });

  assert.equal(out.evidence_ready, false);
  assert.equal(out.reason, "tui_result_json_missing");
  assert.equal(out.finding.code, "tui_result_json_missing");
});

test("TUI evidence cycle returns ready when result.json exists", async () => {
  const workspaceRoot = await mkdtemp(join(tmpdir(), "tui-evidence-"));
  const goal = { id: "goal_ready" };
  const dir = join(workspaceRoot, ".gptwork", "goals", goal.id);
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, "result.json"), JSON.stringify({
    changed_files: ["backend/src/example.mjs"],
    tests: "node --test passed",
    commit: "abcdef1",
    verification: { passed: true }
  }));

  const out = await runCodexTuiEvidenceCycle({
    task: { id: "task_ready" },
    goal,
    sessionId: "session_ready",
    workspaceRoot,
    maxWaitMs: 1,
    pollMs: 1,
    sleepFn: async () => {},
    collectFn: async () => ({ result_json: { ok: true } }),
  });

  assert.equal(out.evidence_ready, true);
});
```

### 6.2 修改测试

`backend/test/stale-state-sweeper.test.mjs`

```js
test("sweeper: TUI session-started task without durable evidence is not force-completed", () => {
  const staleThresholdMs = 300_000;
  const now = Date.now();
  const actions = sweepStaleTaskStates({
    tasks: [{
      id: "review_stale_tui_session_only",
      status: "waiting_for_review",
      updated_at: new Date(now - staleThresholdMs * 4).toISOString(),
      metadata: {
        codex_execution_provider: "codex_tui_goal",
        execution_backend: "codex_tui_superpowers",
      },
      result: {
        kind: "codex_tui_session_started",
        provider: "codex_tui_goal",
        session_id: "goal_x_task_y",
        changed_files: [],
        tests: null,
        commit: "none",
      },
    }],
    now,
    staleThresholdMs,
  });

  assert.equal(actions.length, 0);
});
```

### 6.3 必跑命令

```bash
cd /home/a9017/mcp/workspace/gpt-codex-workspace

npm --prefix backend run check:imports
cd backend && find src -name '*.mjs' -type f -print0 | sort -z | xargs -0 -r -n 1 -P 8 node --check

node --test test/codex-tui-pty-adapter.test.mjs
node --test test/codex-tui-session-*.test.mjs
node --test test/stale-state-sweeper.test.mjs
node --test test/codex-tui-evidence-cycle.test.mjs
```

---

## 7. P0 Smoke Task

只创建一个 smoke task，不再批量创建大任务。

```json
{
  "title": "P0-TUI-SMOKE Durable Evidence Loop",
  "metadata": {
    "codex_execution_provider": "codex_tui_goal",
    "execution_backend": "codex_tui_superpowers",
    "requires_superpowers": true,
    "must_use_tui": true,
    "smoke": true
  }
}
```

任务内容：

```text
目标：验证 GPTWork TUI provider 能从 session_started 进入 durable evidence collected。

要求：
1. 使用 Codex TUI + Superpowers。
2. 不修改业务代码，只写 smoke evidence：
   - .gptwork/goals/<goal_id>/result.json
   - .gptwork/goals/<goal_id>/result.md
3. result.json 必须包含：
   - changed_files: []
   - tests: "smoke evidence only"
   - verification: { passed: true }
   - commit: "none"
4. worker 必须 collect 到 evidence。
5. task 不能因为 session_started 自动 completed。
```

通过标准：

```text
codex_tui_session_started
→ result.json exists
→ codex_tui_collect returns evidence_ready=true
→ acceptance recognizes smoke profile
→ task completed or waiting_for_review with valid evidence
```

---

## 8. 禁止事项

```text
禁止：批量重启 worker
禁止：在 worker tick 运行时强制 safe_restart
禁止：把 session_id 当完成证据
禁止：让 stale sweeper 自动完成 TUI session-only task
禁止：在 dirty worktree 中覆盖并行任务文件
禁止：没有 result evidence 就 complete_task
```

---

## 9. 最终验收口径

TUI/Superpowers backend 可称为 MVP 成立，必须同时满足：

```text
1. 一个 TUI smoke task 真实写出 result.json/result.md
2. codex_tui_collect 能读到该 evidence
3. task.result 包含 evidence_ready=true 或 verification.passed=true
4. stale sweeper 不会完成 session-only task
5. Superpowers missing 时 TUI provider blocked，而不是空跑
6. service restart 后旧 session record 能被 status/read 正确标记 detached
```

在上述全部通过前，所有复杂 P0-TUI-01~06 任务都只能算：

```text
not valid / awaiting evidence
```
