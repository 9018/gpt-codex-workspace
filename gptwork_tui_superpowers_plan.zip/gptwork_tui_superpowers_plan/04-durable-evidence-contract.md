# Durable Evidence Contract

## 必须写出的文件

```text
.gptwork/goals/<goal_id>/result.json
.gptwork/goals/<goal_id>/result.md
```

## result.json schema

```json
{
  "kind": "codex_tui_result",
  "provider": "codex_tui_goal",
  "execution_backend": "codex_tui_superpowers",
  "goal_id": "goal_xxx",
  "task_id": "task_xxx",
  "summary": "What changed",
  "changed_files": [],
  "tests": "Exact command and result",
  "verification": {
    "passed": true,
    "commands": [
      {
        "command": "node --test ...",
        "exit_code": 0,
        "summary": "passed"
      }
    ],
    "findings": []
  },
  "commit": "none",
  "blockers": []
}
```

## 缺失 result.json

collector 返回：

```json
{
  "evidence_ready": false,
  "reason": "tui_result_json_missing",
  "verification": {
    "passed": false,
    "findings": [
      {
        "severity": "major",
        "code": "tui_result_json_missing"
      }
    ]
  }
}
```
