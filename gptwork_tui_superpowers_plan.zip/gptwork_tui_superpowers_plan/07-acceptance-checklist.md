# Acceptance Checklist

- [ ] `codex_tui_goal` starts a TUI session.
- [ ] Session record is written under `.gptwork/codex-tui-sessions/`.
- [ ] TUI writes `.gptwork/goals/<goal_id>/result.json`.
- [ ] TUI writes `.gptwork/goals/<goal_id>/result.md`.
- [ ] `codex_tui_collect` returns `evidence_ready=true`.
- [ ] Missing result evidence leaves task in review/blocking state.
- [ ] Stale sweeper does not complete session-only TUI tasks.
- [ ] Superpowers missing blocks provider.
- [ ] No worker safe restart is triggered while a tick is running.
