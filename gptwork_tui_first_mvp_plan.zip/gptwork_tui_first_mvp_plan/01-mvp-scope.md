# 01. MVP 范围

## 做什么

本 MVP 实现一个可上线的 TUI-first branch loop：

```text
Goal created
  -> branch/worktree created
  -> Claude Code TUI execute
  -> evidence collected
  -> Codex TUI accept
  -> merge gate preview/apply
  -> Claude Code exec advance
```

## 不做什么

本 MVP 明确不做：

1. 完整 runtime matrix。
2. OpenHands adapter。
3. GPTWork attach 外部 TUI session。
4. GPTWork 采集用户在 TUI 中说过什么。
5. 自动判断用户什么时候人工接管。
6. 安全策略、沙箱、权限风控。

## 兼容性要求

1. 现有 `codex_exec` 路径不得被破坏。
2. 现有 `codex_tui_*` 工具不得被删除或重命名。
3. 新能力默认通过配置启用，不应静默改变旧任务行为。
4. 旧的 goal/task 数据仍可读取；没有 workspace metadata 的旧 goal 应显示明确诊断。

## 配置

```env
GPTWORK_LOOP_STRATEGY=tui_first_branch_loop
GPTWORK_EXECUTE_PROVIDER=claude_tui_goal
GPTWORK_ACCEPT_PROVIDER=codex_tui_goal
GPTWORK_ADVANCE_PROVIDER=claude_exec_goal
GPTWORK_GOAL_WORKTREE_ROOT=.gptwork/worktrees
GPTWORK_GOAL_BRANCH_PREFIX=gptwork/goal
GPTWORK_MERGE_TARGET_BRANCH=main
GPTWORK_CLAUDE_COMMAND=claude
GPTWORK_CODEX_COMMAND=codex
GPTWORK_CLAUDE_TUI_ENABLED=true
GPTWORK_CODEX_TUI_ENABLED=true
GPTWORK_CLAUDE_EXEC_ADVANCE_ENABLED=true
```
