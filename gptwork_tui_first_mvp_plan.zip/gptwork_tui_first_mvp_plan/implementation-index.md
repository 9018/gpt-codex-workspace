# Implementation Index

## New source files

```text
backend/src/goal-worktree-service.mjs
backend/src/goal-branch-service.mjs
backend/src/goal-workspace-status.mjs
backend/src/stage-invocation-contract.mjs
backend/src/stage-loop-service.mjs
backend/src/providers/claude-tui-goal-provider.mjs
backend/src/providers/codex-tui-accept-provider.mjs
backend/src/providers/claude-exec-advance-provider.mjs
backend/src/evidence-bundle-service.mjs
backend/src/acceptance-contract-service.mjs
backend/src/acceptance-result-normalizer.mjs
backend/src/merge-gate-service.mjs
backend/src/merge-decision-service.mjs
backend/src/tool-groups/goal-merge-tools-group.mjs
backend/src/tui-first-loop-orchestrator.mjs
backend/src/product-loop-status-view.mjs
backend/scripts/e2e-tui-first-loop.mjs
backend/scripts/release-tui-first-loop-gate.mjs
```

## Existing files to modify

```text
backend/src/runtime-config.mjs
backend/src/goal-lifecycle.mjs
backend/src/goal-files.mjs
backend/src/server-tools.mjs
backend/src/product-status-view.mjs
backend/src/tool-groups/runtime-status-tools-group.mjs
backend/package.json
backend/.env.example
```

## Package scripts to add

```json
{
  "scripts": {
    "e2e:tui-first-loop": "node scripts/e2e-tui-first-loop.mjs",
    "release:tui-first-loop-gate": "node scripts/release-tui-first-loop-gate.mjs"
  }
}
```

## Public MCP tools to add

```text
goal_workspace_status(goal_id)
goal_rescan(goal_id)
goal_start_execute(goal_id)
goal_start_acceptance(goal_id)
goal_merge_preview(goal_id)
goal_merge_apply(goal_id)
goal_advance(goal_id)
```

## Public MCP tools that must remain unchanged

```text
codex_tui_start_goal
codex_tui_status
codex_tui_read
codex_tui_send
codex_tui_stop
codex_tui_collect
```

## Minimal execution sequence

```text
create_goal
  -> ensureGoalWorkspace
  -> runStage(execute, claude_tui_goal)
  -> collectEvidenceBundle
  -> runStage(accept, codex_tui_goal)
  -> previewMergeGate
  -> applyMergeGate
  -> runStage(advance, claude_exec_goal)
```
