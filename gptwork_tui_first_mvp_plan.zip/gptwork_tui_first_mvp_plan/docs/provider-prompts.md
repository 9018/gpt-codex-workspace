# Provider Prompts

## Claude Code TUI Execute

发送给 Claude TUI 的原生 `/goal`：

```text
/goal Read .gptwork/goals/<goal_id>/claude.entry.md first. Execute this goal in the current goal worktree only. Continue until result.md and result.json exist, verification evidence is recorded, the candidate worktree is clean, and commit evidence is present.
```

`claude.entry.md` 必须强调：

```text
- Work only inside current goal worktree.
- Do not edit main directly.
- Do not mark completion by conversation only.
- Write result.md and result.json.
- Record tests/verification.
- Commit changes or explain no-change reason.
- Leave worktree clean.
```

## Codex TUI Acceptance

发送给 Codex TUI 的原生 `/goal`：

```text
/goal Read .gptwork/goals/<goal_id>/codex.acceptance.entry.md first. Review the candidate branch evidence against acceptance.contract.json. Write acceptance.result.json with verdict, findings, reviewed_candidate_head, and merge_recommendation.
```

`codex.acceptance.entry.md` 必须强调：

```text
- Review evidence.bundle.json, result.md, result.json, acceptance.contract.json.
- Do not rely on TUI conversation as evidence.
- Set reviewed_candidate_head to current HEAD.
- If current HEAD changes after review, GPTWork will reject merge until re-accepted.
```

## Claude Code Exec Advance

命令：

```bash
claude -p "/goal Read .gptwork/goals/<goal_id>/advance.entry.md. Output only valid JSON matching advance.result.json. Decide one of: create_next_goal, request_repair, ask_user, stop."
```

`advance.entry.md` 必须强调：

```text
- Read acceptance.result.json.
- Read merge.decision.json and merge.result.json if present.
- Decide next workflow action.
- Output only valid JSON.
```
