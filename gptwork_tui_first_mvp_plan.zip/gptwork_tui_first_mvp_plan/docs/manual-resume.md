# Manual Resume 设计

## 定义

Manual Resume 指用户自行进入 goal worktree，然后使用 Claude Code 或 Codex 的原生 `/resume` 接管。

GPTWork 不需要知道用户什么时候进入，也不采集用户在 TUI 中的对话。

## 用户操作

```bash
cd .gptwork/worktrees/<goal_id>
claude
/resume
```

或：

```bash
cd .gptwork/worktrees/<goal_id>
codex
/resume
```

## GPTWork 如何继续

GPTWork 后续执行 `goal_rescan`：

```text
1. 读取 candidate branch HEAD
2. 读取 git status
3. 读取 result.md/result.json
4. 重新生成 evidence.bundle.json
5. 如果 acceptance.result.json 的 reviewed_candidate_head 过期，则要求重新验收
6. 如果 acceptance 仍然有效且 merge gate 通过，则允许 merge
```

## 不做的事情

GPTWork 不做：

- 不 attach 用户终端。
- 不读取用户 TUI 对话。
- 不判断用户是否接管。
- 不要求 `gw take/gw done`。

## 安全边界

本方案不考虑安全，但产品稳定性上仍要求：

- 用户应只在 goal worktree 中修改。
- main 只能由 merge gate 合并。
- dirty worktree 不允许 merge。
- 验收 head 过期不允许 merge。
