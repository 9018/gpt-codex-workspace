# Rollout Plan

## Phase 0：只加能力，不切默认

- 新增 branch/worktree service。
- 新增 contracts。
- 新增 merge preview。
- 不改变旧 codex_exec 默认路径。

## Phase 1：单 goal 手动验证

- 创建一个测试 goal。
- 生成 worktree。
- 人工进入 worktree 用 Claude/Codex `/resume` 修改。
- 运行 evidence rescan。
- 人工写 acceptance.result.json。
- merge preview 验证阻断条件。

## Phase 2：TUI-first loop smoke

- Claude TUI execute 自动启动。
- Codex TUI accept 自动启动。
- Claude exec advance 自动运行。
- 不自动 merge，只 preview。

## Phase 3：Merge gate 自动合并

- 满足 passed + clean + reviewed head current + no conflict 时 merge。
- 写 merge.result.json。

## Phase 4：上线 Gate

- `npm run release:tui-first-loop-gate` 必须通过。
- product status 显示 goal 全链路状态。
