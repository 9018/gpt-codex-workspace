# 02. 状态机

## 重要原则

人工干预不是状态。用户是否进入 worktree、是否 `/resume`、是否修改方向，GPTWork 都不需要知道。

GPTWork 状态只描述可观测的 goal loop 进度。

## 状态枚举

```text
created
workspace_ready
execute_running
execute_evidence_waiting
execute_completed
accept_running
accept_completed
merge_gate_ready
merge_blocked
merged
advance_running
advance_completed
completed
repair_requested
cancelled
```

## 状态转移

```text
created
  -> workspace_ready
  -> execute_running
  -> execute_evidence_waiting
  -> execute_completed
  -> accept_running
  -> accept_completed
  -> merge_gate_ready
  -> merged
  -> advance_running
  -> advance_completed
  -> completed
```

失败或不满足合并条件：

```text
accept_completed
  -> merge_blocked
  -> repair_requested
  -> execute_running
```

冲突或需用户判断：

```text
merge_gate_ready
  -> merge_blocked
```

## 状态与文件条件

| 状态 | 必须条件 |
|---|---|
| workspace_ready | `workspace.json` 存在；branch/worktree 可访问 |
| execute_completed | `result.md`、`result.json` 存在，且 evidence bundle 可生成 |
| accept_completed | `acceptance.result.json` schema valid |
| merge_gate_ready | acceptance passed；candidate head 未变化；无 conflict；worktree clean |
| merged | `merge.result.json` 存在且包含 merge commit |
| advance_completed | `advance.result.json` schema valid |

## 人工干预如何进入状态机

人工干预不进入状态机。它只影响下一次 `goal_rescan` 结果：

```text
用户手动修改 + commit
  -> goal_rescan
  -> candidate_head 更新
  -> evidence.bundle.json 更新
  -> 若 acceptance.reviewed_candidate_head != candidate_head，则需要重新验收
```
