# 00. 决策与术语

## 已定版决策

### D1：采用 branch-first loop

每个 goal 都有独立 candidate branch 与 worktree。

```text
base branch: main
candidate branch: gptwork/goal/<goal_id>
goal worktree: .gptwork/worktrees/<goal_id>
```

GPTWork 不通过暂停信号感知人工接管，也不采集人工干预内容。用户可以随时进入 goal worktree 并使用原生 `/resume`。

### D2：采用 TUI-first stage 策略

MVP 固定为：

```text
execute = claude_tui_goal
accept  = codex_tui_goal
advance = claude_exec_goal
```

### D3：人工干预不是状态

人工干预只会表现为 candidate branch 上的提交、文件变化、测试结果、result 文件变化。GPTWork 后续通过 `goal_rescan` 感知最终现场。

### D4：GPTWork 最终控制点是 merge gate

GPTWork 不评价 TUI 对话内容，不判断“人是否接管”。GPTWork 只判断：candidate branch 是否满足合并条件。

### D5：main 不参与执行

任何执行、修复、验收都不得直接修改 main。main 只通过 `goal_merge_apply` 变更。

## 术语

| 术语 | 含义 |
|---|---|
| Goal | 用户下发的目标。GPTWork 的最高业务对象。 |
| Candidate branch | 当前 goal 的候选代码分支，例如 `gptwork/goal/goal_xxx`。 |
| Goal worktree | candidate branch 对应的独立工作目录。 |
| Execute stage | Claude Code TUI 执行阶段。 |
| Accept stage | Codex TUI 验收阶段。 |
| Advance stage | Claude Code exec 推进阶段。 |
| Evidence bundle | GPTWork 从 Git、result 文件、测试记录收集的持久证据。 |
| Merge gate | GPTWork 基于证据和验收结果决定是否合并 candidate branch。 |
| Manual resume | 用户自己进入 goal worktree 后使用原生 `claude/codex /resume`。GPTWork 不采集。 |

## 严禁混淆

```text
错误：GPTWork 管理人类 TUI 干预。
正确：GPTWork 通过 branch/worktree 隔离人类干预。
```

```text
错误：TUI 是 exec 失败后的 fallback。
正确：TUI 是本 MVP 的一等 runtime，执行与验收默认走 TUI。
```

```text
错误：验收依赖 TUI 屏幕输出。
正确：验收依赖 evidence.bundle.json、acceptance.result.json、Git 状态和 result contract。
```
