# Test Plan

## Unit Tests

### goal-worktree-service

- creates branch when missing
- attaches worktree when branch exists
- refuses mismatched existing worktree
- writes workspace.json
- writes resume.md
- rescans candidate head and dirty state

### stage-invocation-contract

- execute stage selects claude_tui_goal
- accept stage selects codex_tui_goal
- advance stage selects claude_exec_goal
- each stage has expected entry file and output files

### providers

- claude_tui_goal disabled returns blocked diagnostic
- claude_tui_goal enabled spawns `claude` in worktree cwd
- codex_tui_goal enabled spawns `codex` in worktree cwd
- claude_exec_goal invokes `claude -p` and writes advance logs

### evidence-bundle-service

- detects result.md/result.json presence
- detects clean vs dirty worktree
- captures commits since merge target
- updates candidate head after manual commit

### merge-gate-service

- rejects failed acceptance
- rejects dirty worktree
- rejects stale reviewed_candidate_head
- rejects missing result files
- rejects merge conflicts
- returns merge when all checks pass

## Integration Tests

- create goal -> branch/worktree -> simulated result -> evidence -> simulated acceptance -> merge preview
- manual commit after acceptance -> merge preview rejects stale reviewed_candidate_head
- re-accept latest head -> merge preview passes

## E2E

Script:

```bash
npm run e2e:tui-first-loop
```

Checks:

1. temp repo initialized
2. goal branch/worktree created
3. simulated execute writes result files
4. simulated acceptance passes
5. merge commit created
6. advance.result.json written

## Regression

- existing codex_exec path still passes syntax/import checks
- existing codex_tui_* public tool names remain exposed
