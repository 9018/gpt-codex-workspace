# GPTWork TUI-first Branch-loop MVP 上线方案

版本：v1.0

本文档包定义一个语义严谨、边界明确的 GPTWork MVP：

```text
ChatGPT 下发 Goal
  -> GPTWork 创建 candidate branch + goal worktree
  -> Claude Code TUI 在 goal worktree 中执行 `/goal`
  -> 用户可随时进入该 worktree，用 Claude/Codex 原生 `/resume` 人工干预
  -> GPTWork 不采集人工干预过程，只在后续 rescan branch/worktree 现场
  -> Codex TUI 在同一个 candidate branch 上验收 `/goal`
  -> GPTWork merge gate 判断 candidate branch 是否可合并到 main
  -> 通过后 merge
  -> Claude Code exec 生成下一步推进决策
```

## 固定 MVP 策略

```env
GPTWORK_EXECUTE_PROVIDER=claude_tui_goal
GPTWORK_ACCEPT_PROVIDER=codex_tui_goal
GPTWORK_ADVANCE_PROVIDER=claude_exec_goal
```

此 MVP 不做完整 runtime matrix，不做内置人工 TUI 采集，不做 `gw take/gw done`。人工干预通过 Git 分支和 worktree 隔离自然兼容。

## 核心不变量

1. **GPTWork 是 goal branch loop control plane，不是 TUI session 管理器。**
2. **人工干预不是 GPTWork 状态。**用户可直接 `cd <goal_worktree>` 后使用原生 `claude/codex /resume`。
3. **candidate branch/worktree 是隔离边界。**所有自动执行、TUI 验收、人工干预都发生在 goal worktree。
4. **main 只由 merge gate 修改。**执行阶段、验收阶段不得直接修改 main。
5. **最终判断只看持久证据。**GPTWork 不依赖 TUI 屏幕文本，不采集人工过程，只读取 Git、result、evidence、acceptance 文件。
6. **TUI 是一等 runtime，不是 fallback。**本 MVP 的执行与验收均优先使用 TUI。
7. **exec 只用于推进。**推进需要结构化决策，默认使用 Claude Code exec。

## 文档结构

```text
README.md
00-decisions-and-terms.md
01-mvp-scope.md
02-state-machine.md
goals/
  goal-1-branch-first-workspace.md
  goal-2-tui-first-stage-loop.md
  goal-3-evidence-and-acceptance.md
  goal-4-merge-gate.md
  goal-5-product-status-and-e2e-gate.md
contracts/
  goal-workspace.schema.json
  stage-invocation.schema.json
  evidence-bundle.schema.json
  acceptance-result.schema.json
  merge-decision.schema.json
  advance-result.schema.json
docs/
  manual-resume.md
  provider-prompts.md
  rollout-plan.md
env/
  runtime.env.example
snippets/
  backend/src/*.mjs
  backend/src/providers/*.mjs
  backend/src/tool-groups/*.mjs
  backend/scripts/*.mjs
tests/
  test-plan.md
```

## 5 个上线 Goal

1. **Branch-first Goal Workspace 基座**：每个 goal 一个 branch + worktree。
2. **TUI-first 固定 Stage Loop**：Claude TUI 执行，Codex TUI 验收，Claude exec 推进。
3. **Evidence Bundle + Acceptance Contract 稳定化**：所有判断收敛到文件与 Git 现场。
4. **Merge Gate 产品化**：GPTWork 只负责决定 candidate branch 是否合并。
5. **上线级状态机、诊断与 E2E Gate**：串起完整闭环。
