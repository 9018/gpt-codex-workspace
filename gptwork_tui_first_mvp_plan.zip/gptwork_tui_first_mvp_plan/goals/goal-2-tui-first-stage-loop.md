# Goal 2：TUI-first 固定 Stage Loop

## 目标

实现固定 MVP loop：

```text
execute = claude_tui_goal
accept  = codex_tui_goal
advance = claude_exec_goal
```

## 文件名要求

新增：

```text
backend/src/stage-loop-service.mjs
backend/src/stage-invocation-contract.mjs
backend/src/providers/claude-tui-goal-provider.mjs
backend/src/providers/codex-tui-accept-provider.mjs
backend/src/providers/claude-exec-advance-provider.mjs
contracts/stage-invocation.schema.json
```

改造：

```text
backend/src/codex-tui-session-manager.mjs 或新增通用 tui-session-manager 时保持 codex_tui_* 兼容
backend/src/tool-groups/codex-tui-tools-group.mjs
backend/src/server-tools.mjs
```

## Stage Invocation 语义

```json
{
  "invocation_id": "inv_xxx",
  "goal_id": "goal_xxx",
  "task_id": "task_xxx",
  "stage": "execute",
  "provider": "claude_tui_goal",
  "cwd": ".gptwork/worktrees/goal_xxx",
  "entry_file": ".gptwork/goals/goal_xxx/claude.entry.md",
  "expected_outputs": [
    ".gptwork/goals/goal_xxx/result.md",
    ".gptwork/goals/goal_xxx/result.json"
  ]
}
```

## Claude TUI execute prompt

```text
/goal Read .gptwork/goals/<goal_id>/claude.entry.md first. Execute this goal in the current goal worktree only. Continue until result.md and result.json exist, verification evidence is recorded, the candidate worktree is clean, and commit evidence is present.
```

## Codex TUI accept prompt

```text
/goal Read .gptwork/goals/<goal_id>/codex.acceptance.entry.md first. Review the candidate branch evidence against acceptance.contract.json. Write acceptance.result.json with verdict, findings, reviewed_candidate_head, and merge_recommendation.
```

## Claude exec advance prompt

```text
/goal Read .gptwork/goals/<goal_id>/advance.entry.md. Output only valid JSON matching advance.result.json. Decide one of: create_next_goal, request_repair, ask_user, stop.
```

## 验收标准

- `runStage({ stage: 'execute' })` 默认启动 Claude TUI provider。
- `runStage({ stage: 'accept' })` 默认启动 Codex TUI provider。
- `runStage({ stage: 'advance' })` 默认启动 Claude exec provider。
- 所有 provider cwd 都指向 goal worktree。
- 任一 stage 失败时，不修改 main。
- codex 旧 TUI 工具继续存在。
