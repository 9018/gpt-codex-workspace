# Goal 1：Branch-first Goal Workspace 基座

## 目标

将 GPTWork 的执行现场从 canonical repo/main 分支迁移到每个 goal 独立的 candidate branch + worktree。

## 语义

每个 goal 绑定一个不可混淆的 workspace：

```json
{
  "goal_id": "goal_xxx",
  "base_branch": "main",
  "base_sha": "abc123",
  "candidate_branch": "gptwork/goal/goal_xxx",
  "worktree_path": ".gptwork/worktrees/goal_xxx",
  "merge_target": "main",
  "workspace_status": "active"
}
```

## 文件名要求

新增：

```text
backend/src/goal-worktree-service.mjs
backend/src/goal-branch-service.mjs
backend/src/goal-workspace-status.mjs
contracts/goal-workspace.schema.json
```

改造：

```text
backend/src/goal-lifecycle.mjs
backend/src/goal-files.mjs
backend/src/task-resolution.mjs 或现有 task repository resolution 模块
```

## 行为要求

1. `create_goal` 后调用 `ensureGoalWorkspace(goalId)`。
2. 创建 candidate branch：`gptwork/goal/<goal_id>`。
3. 创建 worktree：`.gptwork/worktrees/<goal_id>`。
4. 在 worktree 内生成 goal 文件。
5. 所有后续 stage 的 cwd 均指向该 worktree。
6. main 只作为 merge target，不被 stage 直接修改。

## 代码片段

参考：`snippets/backend/src/goal-worktree-service.mjs`

核心接口：

```js
export async function ensureGoalWorkspace({ goal, config, runGit = git }) {
  const repo = config.defaultRepoPath;
  const goalId = assertGoalId(goal.id);
  const branch = `${config.goalBranchPrefix || 'gptwork/goal'}/${goalId}`;
  const worktreePath = join(config.defaultWorkspaceRoot, '.gptwork', 'worktrees', goalId);
  const baseBranch = goal.base_branch || config.defaultBranch || 'main';
  const baseSha = await gitOutput(repo, ['rev-parse', baseBranch], runGit);

  await ensureBranchAndWorktree({ repo, branch, worktreePath, baseBranch, runGit });

  const workspace = {
    goal_id: goalId,
    base_branch: baseBranch,
    base_sha: baseSha,
    candidate_branch: branch,
    worktree_path: worktreePath,
    merge_target: baseBranch,
    workspace_status: 'active'
  };

  await writeJson(join(worktreePath, '.gptwork', 'goals', goalId, 'workspace.json'), workspace);
  await writeResumeMarkdown({ worktreePath, goalId, workspace });
  return workspace;
}
```

## 验收标准

- 创建新 goal 后，`workspace.json` 存在。
- `git branch --show-current` 在 worktree 内返回 `gptwork/goal/<goal_id>`。
- `git rev-parse main` 不因为 execute stage 改变。
- 人工在 worktree 中 commit 后，`rescanGoalWorkspace` 能看到新 candidate head。
- stale branch/worktree 情况返回明确错误，不静默重建或覆盖人工工作。
