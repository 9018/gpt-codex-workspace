# Goal 3：Evidence Bundle + Acceptance Contract 稳定化

## 目标

将执行结果、人工干预结果、TUI 验收结果收敛到可机器判断的持久文件。

## 文件名要求

新增：

```text
backend/src/evidence-bundle-service.mjs
backend/src/acceptance-contract-service.mjs
backend/src/acceptance-result-normalizer.mjs
contracts/evidence-bundle.schema.json
contracts/acceptance-result.schema.json
```

## Evidence Bundle 文件

```text
.gptwork/goals/<goal_id>/evidence.bundle.json
```

必须包含：

- `goal_id`
- `base_branch`
- `base_sha`
- `candidate_branch`
- `candidate_head`
- `merge_base`
- `worktree_clean`
- `changed_files`
- `commits`
- `result_md_present`
- `result_json_present`
- `tests`
- `diff_stat`

## Acceptance Result 文件

```text
.gptwork/goals/<goal_id>/acceptance.result.json
```

必须包含：

- `verdict`
- `confidence`
- `blocking_findings`
- `required_changes`
- `merge_recommendation`
- `reviewed_candidate_head`

## 重要规则

1. TUI 日志不是验收证据。
2. 人工干预内容不是验收证据。
3. 验收只看 candidate branch 现场和 result/evidence 文件。
4. acceptance reviewed head 必须等于当前 candidate head，否则 merge gate 拒绝。

## 验收标准

- `collectEvidenceBundle(goal_id)` 可重复执行，且幂等。
- 人工 commit 后重新收集 evidence 时，candidate head 更新。
- result 文件缺失时 evidence 能明确标记。
- acceptance.result.json schema 不合法时 merge gate 拒绝。
