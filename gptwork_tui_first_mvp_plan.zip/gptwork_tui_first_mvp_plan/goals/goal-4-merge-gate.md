# Goal 4：Merge Gate 产品化

## 目标

GPTWork 作为分支裁判，基于 evidence 和 acceptance 判断 candidate branch 是否合并进 main。

## 文件名要求

新增：

```text
backend/src/merge-gate-service.mjs
backend/src/merge-decision-service.mjs
backend/src/tool-groups/goal-merge-tools-group.mjs
contracts/merge-decision.schema.json
```

## Merge Gate 决策

```json
{
  "decision": "merge | reject | request_repair | rebase_needed | conflict | ask_user",
  "reason": "...",
  "checks": {
    "acceptance_passed": true,
    "worktree_clean": true,
    "result_contract_valid": true,
    "reviewed_head_current": true,
    "merge_conflict": false
  }
}
```

## 允许 merge 的条件

全部满足才允许 merge：

1. `acceptance.result.json.verdict = passed`
2. `acceptance.result.json.merge_recommendation = merge`
3. `acceptance.result.json.reviewed_candidate_head = evidence.candidate_head`
4. `evidence.worktree_clean = true`
5. `result.md` 和 `result.json` 存在
6. 无 merge conflict
7. schema 均 valid

## Merge 方式

```bash
git checkout main
git merge --no-ff gptwork/goal/<goal_id> -m "merge: <goal_id> <title>"
```

合并结果写：

```text
.gptwork/goals/<goal_id>/merge.result.json
```

## 验收标准

- failed/partial/blocked 不可 merge。
- dirty worktree 不可 merge。
- reviewed head 过期不可 merge。
- conflict 时返回 conflict，不自动硬解。
- 满足条件时可生成 merge commit。
