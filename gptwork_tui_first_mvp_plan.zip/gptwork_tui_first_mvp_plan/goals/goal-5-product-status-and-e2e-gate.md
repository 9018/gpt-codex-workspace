# Goal 5：上线级状态机、诊断与端到端 Gate

## 目标

把前四个 Goal 串成可上线 MVP，并提供状态视图、诊断和端到端 gate。

## 文件名要求

新增：

```text
backend/src/tui-first-loop-orchestrator.mjs
backend/src/product-loop-status-view.mjs
backend/scripts/e2e-tui-first-loop.mjs
backend/scripts/release-tui-first-loop-gate.mjs
contracts/advance-result.schema.json
```

改造：

```text
backend/src/product-status-view.mjs
backend/src/runtime-status-tools-group.mjs
backend/package.json
```

## 产品状态视图

```json
{
  "goal_id": "goal_xxx",
  "state": "merge_gate_ready",
  "base_branch": "main",
  "candidate_branch": "gptwork/goal/goal_xxx",
  "worktree_path": ".gptwork/worktrees/goal_xxx",
  "execute_provider": "claude_tui_goal",
  "accept_provider": "codex_tui_goal",
  "advance_provider": "claude_exec_goal",
  "candidate_head": "def456",
  "acceptance_verdict": "passed",
  "merge_decision": "merge",
  "next_action": "goal_merge_apply"
}
```

## E2E Gate 要求

脚本：

```bash
npm run e2e:tui-first-loop
```

验证：

1. 创建 goal。
2. 创建 branch + worktree。
3. 模拟 Claude 执行写 result.md/result.json。
4. 生成 evidence.bundle.json。
5. 模拟 Codex TUI 写 acceptance.result.json = passed。
6. merge preview = merge。
7. merge apply 成功。
8. 模拟 Claude exec advance 写 advance.result.json。
9. product status 显示 completed 或 advance_completed。

## 验收标准

- 单个状态视图能展示全链路状态。
- rescan 能正确更新 branch/evidence/merge readiness。
- E2E gate 通过。
- 旧 codex_exec 与 codex_tui_* 不被破坏。
